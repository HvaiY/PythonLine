def receive(text):
    return "收到来自%s的消息" %text