def send(name):
    print("正在发送消息给%s...."%name)